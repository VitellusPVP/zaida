<!--- Please do not ask questions or create discussion in the bug tracker. Use https://nukkitx.com -->
<!--- ONLY POST ISSUES WITH A CLEAN SERVER ON THE LATEST VERSION -->
## Generated Bug Report

<!--- DO NOT OPEN A ISSUE IF THIS IS A PLUGIN ERROR -->
PLUGIN ERROR: FALSE

### Expected Behavior
<!--- What would you expect to happen -->


### Actual Behavior
<!--- What actually happened -->


### Steps to Reproduce
<!--- Reliable steps which someone can use to reproduce the issue. Please do not create issues for non reproducible bug! -->


### OS and Versions

* Nukkit Version: git-6d83aea 
* Java Version: OpenJDK 64-Bit Server VM (1.8.0_191-8u191-b12-0ubuntu0.16.04.1-b12)

* Host Configuration: 

| Item | Value |
|:----:|:-----:|
| Host OS | Linux-amd64 [3.10.107-1-tlinux2_kvm_guest-0046.cd.nosign] |  
| Memory(RAM) | 33.5 GB | 
| Storage Size | 5.4 GB | 
| Storage Type | Disk 0:(avail=5.4 GB, total=5.4 GB)  | 
| CPU Type | UNKNOWN | 
| CPU Core Count | 1 | 

### Crashdump, Backtrace or Other Files

```
java.lang.RuntimeException: java.lang.NumberFormatException: For input string: ""
	at cn.nukkit.level.generator.Flat.parsePreset(Flat.java:145)
	at cn.nukkit.level.generator.Flat.generateChunk(Flat.java:160)
	at cn.nukkit.level.generator.task.PopulationTask.generationTask(PopulationTask.java:103)
	at cn.nukkit.level.generator.task.PopulationTask.syncGen(PopulationTask.java:48)
	at cn.nukkit.level.generator.task.PopulationTask.syncGen(PopulationTask.java:53)
	at cn.nukkit.level.generator.task.PopulationTask.syncGen(PopulationTask.java:53)
	at cn.nukkit.level.generator.task.PopulationTask.syncGen(PopulationTask.java:53)
	at cn.nukkit.level.generator.task.PopulationTask.syncGen(PopulationTask.java:53)
	at cn.nukkit.level.generator.task.PopulationTask.syncGen(PopulationTask.java:53)
	at cn.nukkit.level.generator.task.PopulationTask.syncGen(PopulationTask.java:53)
	at cn.nukkit.level.generator.task.PopulationTask.syncGen(PopulationTask.java:53)
	at cn.nukkit.level.generator.task.PopulationTask.syncGen(PopulationTask.java:53)
	at cn.nukkit.level.generator.task.PopulationTask.syncGen(PopulationTask.java:53)
	at cn.nukkit.level.generator.task.PopulationTask.onRun(PopulationTask.java:43)
	at cn.nukkit.scheduler.AsyncTask.run(AsyncTask.java:23)
	at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1149)
	at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:624)
	at java.lang.Thread.run(Thread.java:748)
Caused by: java.lang.NumberFormatException: For input string: ""
	at java.lang.NumberFormatException.forInputString(NumberFormatException.java:65)
	at java.lang.Integer.parseInt(Integer.java:592)
	at java.lang.Integer.valueOf(Integer.java:766)
	at cn.nukkit.level.generator.Flat.parsePreset(Flat.java:92)
	... 17 more

```